SlumDrugs resource pack
=======================
Generated from drugs.yml by /drugs pack.

Includes 25 PixelLab item textures: products, seeds, harvests, packages,
supplies and station icons. Existing PNG files are never overwritten.
Replace any texture in assets/slumdrugs/textures/item to customize it.

To use it:
  1. Use the resourcepack.zip generated beside this folder.
  2. Drop the zip in your client's resourcepacks folder, or host it and set
     resource-pack in server.properties.

Plant growth stages use the vanilla crop models, so a growing plot already
shows its stage without any pack changes.
